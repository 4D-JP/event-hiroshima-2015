CREATE INDEX code_new ON POSTCODE_PREFECTURE
(
	code_new
);

CREATE INDEX kanji_prefecture ON POSTCODE_PREFECTURE
(
	kanji_prefecture
);

CREATE INDEX kanji_city ON POSTCODE_PREFECTURE
(
	kanji_city
);

CREATE INDEX kanji_town ON POSTCODE_PREFECTURE
(
	kanji_town
);

CREATE INDEX phonic_prefecture ON POSTCODE_PREFECTURE
(
	phonic_prefecture
);

CREATE INDEX phonic_city ON POSTCODE_PREFECTURE
(
	phonic_city
);

CREATE INDEX phonic_town ON POSTCODE_PREFECTURE
(
	phonic_town
);